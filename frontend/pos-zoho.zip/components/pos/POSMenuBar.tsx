"use client";

import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  ChevronDown,
  SlidersHorizontal,
  Search,
  Eye,
  Printer,
  X,
  Plus,
  Trash2,
  RefreshCw,
  Loader2,
} from "lucide-react";
import { getApiUrl, API_ENDPOINTS } from "@/lib/api-config";
import { getAuthHeadersWithToken } from "@/lib/api-utils";
import { useToast } from "@/lib/toast-context";
import { formatCurrency, safeFormatDate } from "@/lib/utils";
import { POSCustomerSelect, Customer } from "@/components/pos/POSCustomerSelect";
import { AddCustomerDialog } from "@/components/pos/AddCustomerDialog";
import { AutocompleteProductSearch } from "@/components/pos/AutocompleteProductSearch";

// ── Types ────────────────────────────────────────────────────────────────────

type PaymentMethod = "cash" | "card" | "mpesa" | "cheque" | "bank_transfer";
type DocumentTypeFilter = "ALL" | "DRAFT" | "QUOTE" | "CREDIT_NOTE" | "INVOICE";
type ApiDocumentType = "DRAFT" | "QUOTE" | "CREDIT_NOTE" | "INVOICE";

interface POSMenuBarProps {
  token: string;
  branchId: string;
  onCustomerCreated: (customer: Customer) => void;
}

interface SalesDocumentCustomer {
  id: string;
  name: string;
}

interface SalesDocumentRecord {
  id: string;
  documentId: string;
  type: ApiDocumentType;
  status: string;
  issueDate: string;
  total: number;
  customer?: SalesDocumentCustomer | null;
}

interface ListDocumentsResponse {
  data: SalesDocumentRecord[];
  total: number;
  limit: number;
  offset: number;
}

interface InvoiceLineItem {
  key: string;
  productId: string;
  description: string;
  quantity: number;
  unitPrice: number;
  taxRate: number;
  discount: number;
}

interface ProductSelection {
  id: string;
  sku: string;
  name: string;
  unit_price: number;
  available: number;
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function todayISO(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function createEmptyLineItem(): InvoiceLineItem {
  return {
    key: crypto.randomUUID(),
    productId: "",
    description: "",
    quantity: 1,
    unitPrice: 0,
    taxRate: 0.16,
    discount: 0,
  };
}

function calculateLineAmount(item: InvoiceLineItem): number {
  const subtotal = item.quantity * item.unitPrice;
  const taxAmount = subtotal * item.taxRate;
  return subtotal + taxAmount - item.discount;
}

function calculateLineTotals(items: InvoiceLineItem[]) {
  let subtotal = 0;
  let tax = 0;
  let discount = 0;

  for (const item of items) {
    const lineSubtotal = item.quantity * item.unitPrice;
    subtotal += lineSubtotal;
    tax += lineSubtotal * item.taxRate;
    discount += item.discount;
  }

  const grandTotal = subtotal + tax - discount;
  return { subtotal, tax, discount, grandTotal };
}

const TRANSACTION_ITEMS: { label: string; value: DocumentTypeFilter }[] = [
  { label: "All", value: "ALL" },
  { label: "Sales Drafts", value: "DRAFT" },
  { label: "Quotations", value: "QUOTE" },
  { label: "Credit Notes / Sales Return", value: "CREDIT_NOTE" },
  { label: "Sales Invoices", value: "INVOICE" },
];

const TYPE_LABELS: Record<ApiDocumentType, string> = {
  DRAFT: "Draft",
  QUOTE: "Quotation",
  CREDIT_NOTE: "Credit Note",
  INVOICE: "Invoice",
};

const PAYMENT_METHODS: { value: PaymentMethod; label: string }[] = [
  { value: "cash", label: "Cash" },
  { value: "card", label: "Card" },
  { value: "mpesa", label: "M-Pesa" },
  { value: "cheque", label: "Cheque" },
  { value: "bank_transfer", label: "Bank Transfer" },
];

// ── Component ────────────────────────────────────────────────────────────────

export function POSMenuBar({ token, branchId, onCustomerCreated }: POSMenuBarProps) {
  const router = useRouter();
  const { toast } = useToast();

  // Master
  const [showAddCustomer, setShowAddCustomer] = useState(false);

  // Transactions panel
  const [panelOpen, setPanelOpen] = useState(false);
  const [docTypeFilter, setDocTypeFilter] = useState<DocumentTypeFilter>("ALL");
  const [documents, setDocuments] = useState<SalesDocumentRecord[]>([]);
  const [documentsLoading, setDocumentsLoading] = useState(false);
  const [panelTitle, setPanelTitle] = useState("Transactions");

  // Filter dates
  const [startDate, setStartDate] = useState(todayISO());
  const [endDate, setEndDate] = useState(todayISO());

  // Search
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const searchDebounceRef = useRef<NodeJS.Timeout | null>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // New invoice dialog
  const [invoiceOpen, setInvoiceOpen] = useState(false);
  const [invoiceCustomer, setInvoiceCustomer] = useState<Customer | null>(null);
  const [lineItems, setLineItems] = useState<InvoiceLineItem[]>([createEmptyLineItem()]);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("cash");
  const [invoiceNotes, setInvoiceNotes] = useState("");
  const [invoiceSaving, setInvoiceSaving] = useState(false);

  const formatDate = (date: string | Date | null | undefined) =>
    safeFormatDate(date, { dateStyle: "short", timeStyle: "short" });

  // Debounce search input
  useEffect(() => {
    if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);

    if (searchTerm.length < 2) {
      setDebouncedSearch("");
      return;
    }

    searchDebounceRef.current = setTimeout(() => {
      setDebouncedSearch(searchTerm);
    }, 300);

    return () => {
      if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
    };
  }, [searchTerm]);

  // Focus search input when toggled open
  useEffect(() => {
    if (searchOpen) {
      setTimeout(() => searchInputRef.current?.focus(), 100);
    }
  }, [searchOpen]);

  // Open panel when search has results query
  useEffect(() => {
    if (debouncedSearch.length >= 2) {
      setPanelOpen(true);
      setPanelTitle("Search Results");
    }
  }, [debouncedSearch]);

  // Escape closes transactions panel
  useEffect(() => {
    if (!panelOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        setPanelOpen(false);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [panelOpen]);

  const fetchDocuments = useCallback(async () => {
    if (!branchId || !token) return;

    setDocumentsLoading(true);
    try {
      const params = new URLSearchParams({ branchId });
      if (docTypeFilter !== "ALL") params.set("type", docTypeFilter);
      if (startDate) params.set("startDate", startDate);
      if (endDate) params.set("endDate", endDate);
      if (debouncedSearch.length >= 2) params.set("search", debouncedSearch);

      const res = await fetch(
        `${getApiUrl(API_ENDPOINTS.SALES_DOCUMENTS)}?${params}`,
        { headers: getAuthHeadersWithToken(token) }
      );

      const json = await res.json();

      if (!res.ok || !json.success) {
        toast(json.message || "Failed to fetch documents", "error");
        return;
      }

      const payload = json.data as ListDocumentsResponse | SalesDocumentRecord[];
      const docs = Array.isArray(payload) ? payload : payload.data ?? [];

      // Client-side search fallback when backend omits search filter
      const filtered =
        debouncedSearch.length >= 2
          ? docs.filter((doc) => {
              const q = debouncedSearch.toLowerCase();
              return (
                doc.documentId.toLowerCase().includes(q) ||
                (doc.customer?.name?.toLowerCase().includes(q) ?? false)
              );
            })
          : docs;

      setDocuments(filtered);
    } catch (error) {
      toast("Failed to fetch documents", "error");
      console.error("Fetch documents error:", error);
    } finally {
      setDocumentsLoading(false);
    }
  }, [branchId, token, docTypeFilter, startDate, endDate, debouncedSearch, toast]);

  useEffect(() => {
    if (panelOpen) {
      fetchDocuments();
    }
  }, [panelOpen, fetchDocuments]);

  const handleTransactionSelect = (value: DocumentTypeFilter, label: string) => {
    setDocTypeFilter(value);
    setPanelTitle(label === "All" ? "All Transactions" : label);
    setPanelOpen(true);
  };

  const resetInvoiceForm = () => {
    setInvoiceCustomer(null);
    setLineItems([createEmptyLineItem()]);
    setPaymentMethod("cash");
    setInvoiceNotes("");
  };

  const handleInvoiceClose = () => {
    setInvoiceOpen(false);
    resetInvoiceForm();
  };

  const invoiceTotals = useMemo(() => calculateLineTotals(lineItems), [lineItems]);

  const addLineItem = () => {
    setLineItems((prev) => [...prev, createEmptyLineItem()]);
  };

  const removeLineItem = (key: string) => {
    setLineItems((prev) => (prev.length <= 1 ? prev : prev.filter((i) => i.key !== key)));
  };

  const updateLineItem = (key: string, patch: Partial<InvoiceLineItem>) => {
    setLineItems((prev) =>
      prev.map((item) => (item.key === key ? { ...item, ...patch } : item))
    );
  };

  const handleProductSelect = (key: string, product: ProductSelection) => {
    updateLineItem(key, {
      productId: product.id,
      description: product.name,
      unitPrice: product.unit_price,
    });
  };

  const buildDocumentPayload = (validItems: InvoiceLineItem[], notes: string) => ({
    type: "DRAFT" as const,
    issueDate: new Date().toISOString(),
    customerId: invoiceCustomer?.id || undefined,
    subtotal: invoiceTotals.subtotal,
    tax: invoiceTotals.tax,
    discount: invoiceTotals.discount,
    total: invoiceTotals.grandTotal,
    notes: notes || undefined,
    items: validItems.map((item) => ({
      productId: item.productId,
      quantity: item.quantity,
      unitPrice: item.unitPrice,
      taxRate: item.taxRate,
      discount: item.discount,
      total: calculateLineAmount(item),
    })),
  });

  const createDraftDocument = async (validItems: InvoiceLineItem[], notes: string) => {
    const res = await fetch(getApiUrl(API_ENDPOINTS.SALES_DOCUMENTS), {
      method: "POST",
      headers: getAuthHeadersWithToken(token),
      body: JSON.stringify(buildDocumentPayload(validItems, notes)),
    });

    const json = await res.json();
    if (!res.ok || !json.success) {
      throw new Error(json.message || json.error || "Failed to save draft");
    }

    return json.data as { id: string };
  };

  const convertDraftToInvoice = async (draftId: string) => {
    const res = await fetch(getApiUrl(API_ENDPOINTS.SALES_DOCUMENT_CONVERT(draftId)), {
      method: "POST",
      headers: getAuthHeadersWithToken(token),
      body: JSON.stringify({ type: "INVOICE" }),
    });

    const json = await res.json();
    if (!res.ok || !json.success) {
      throw new Error(json.message || json.error || "Failed to convert draft to invoice");
    }

    return json.data as { id: string };
  };

  const recordInvoicePayment = async (invoiceId: string, amount: number) => {
    const res = await fetch(getApiUrl(API_ENDPOINTS.SALES_DOCUMENT_PAYMENT(invoiceId)), {
      method: "POST",
      headers: getAuthHeadersWithToken(token),
      body: JSON.stringify({
        amount,
        payment_method: paymentMethod,
      }),
    });

    const json = await res.json();
    if (!res.ok || !json.success) {
      throw new Error(json.message || json.error || "Failed to record payment");
    }
  };

  const handleSaveDocument = async (type: "DRAFT" | "INVOICE") => {
    const validItems = lineItems.filter((i) => i.productId);
    if (validItems.length === 0) {
      toast("Add at least one product line item", "warning");
      return;
    }

    setInvoiceSaving(true);
    try {
      if (type === "DRAFT") {
        await createDraftDocument(validItems, invoiceNotes);
        toast("Draft saved successfully", "success");
        handleInvoiceClose();
        return;
      }

      // Invoices must be created via draft → convert (backend rejects direct INVOICE)
      const draft = await createDraftDocument(validItems, invoiceNotes);
      const invoice = await convertDraftToInvoice(draft.id);
      await recordInvoicePayment(invoice.id, invoiceTotals.grandTotal);

      toast("Invoice created successfully", "success");
      handleInvoiceClose();
    } catch (error) {
      toast(error instanceof Error ? error.message : "Failed to save document", "error");
      console.error("Save document error:", error);
    } finally {
      setInvoiceSaving(false);
    }
  };

  return (
    <>
      {/* ── Menu Bar ── */}
      <div className="flex flex-wrap items-center gap-2 rounded-lg border bg-white px-4 py-3 shadow-sm">
        {/* Master */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm">
              Master
              <ChevronDown className="ml-1 h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem onClick={() => setShowAddCustomer(true)}>
              New Customer
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Transactions */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm">
              Transactions
              <ChevronDown className="ml-1 h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            {TRANSACTION_ITEMS.map((item) => (
              <DropdownMenuItem
                key={item.value}
                onClick={() => handleTransactionSelect(item.value, item.label)}
              >
                {item.label}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Filter */}
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm">
              <SlidersHorizontal className="mr-1 h-4 w-4" />
              Filter
            </Button>
          </PopoverTrigger>
          <PopoverContent align="start" className="w-72">
            <div className="space-y-3">
              <p className="text-sm font-medium">Date Range</p>
              <div className="space-y-1">
                <Label className="text-xs text-slate-600">From Date</Label>
                <Input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  max={endDate || undefined}
                  className="h-9"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-slate-600">To Date</Label>
                <Input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  min={startDate || undefined}
                  className="h-9"
                />
              </div>
            </div>
          </PopoverContent>
        </Popover>

        {/* Search */}
        {searchOpen ? (
          <div className="flex items-center gap-1">
            <div className="relative">
              <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <Input
                ref={searchInputRef}
                placeholder="Search documents..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="h-9 w-56 pl-8"
              />
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9"
              onClick={() => {
                setSearchOpen(false);
                setSearchTerm("");
                setDebouncedSearch("");
              }}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        ) : (
          <Button variant="outline" size="sm" onClick={() => setSearchOpen(true)}>
            <Search className="mr-1 h-4 w-4" />
            Search
          </Button>
        )}

        <div className="flex-1" />

        {/* New Sales Invoice */}
        <Button size="sm" onClick={() => setInvoiceOpen(true)}>
          New Sales Invoice
        </Button>
      </div>

      {/* ── Transactions Slide-over Panel ── */}
      {panelOpen && (
        <>
          <div
            className="fixed inset-0 z-40 bg-black/30"
            onClick={() => setPanelOpen(false)}
            aria-hidden="true"
          />
          <div className="fixed inset-y-0 right-0 z-50 flex w-full max-w-3xl flex-col border-l bg-white shadow-xl">
            <div className="flex items-center justify-between border-b px-6 py-4">
              <div>
                <h2 className="text-lg font-semibold">{panelTitle}</h2>
                {(startDate || endDate) && (
                  <p className="text-xs text-muted-foreground">
                    {startDate || "…"} → {endDate || "…"}
                  </p>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={fetchDocuments}
                  disabled={documentsLoading}
                >
                  <RefreshCw className={`mr-1 h-4 w-4 ${documentsLoading ? "animate-spin" : ""}`} />
                  Refresh
                </Button>
                <Button variant="ghost" size="icon" onClick={() => setPanelOpen(false)}>
                  <X className="h-5 w-5" />
                </Button>
              </div>
            </div>

            <div className="flex-1 overflow-auto p-6">
              {documentsLoading ? (
                <div className="flex items-center justify-center py-16">
                  <Loader2 className="h-8 w-8 animate-spin text-slate-400" />
                </div>
              ) : documents.length === 0 ? (
                <div className="py-16 text-center text-slate-500">
                  <p className="font-medium">No documents found</p>
                  <p className="text-sm">Try adjusting filters or date range</p>
                </div>
              ) : (
                <div className="rounded-lg border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-slate-50">
                        <TableHead>Document No</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Customer</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Amount</TableHead>
                        <TableHead className="text-center">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {documents.map((doc) => (
                        <TableRow key={doc.id} className="hover:bg-slate-50">
                          <TableCell className="font-medium">{doc.documentId}</TableCell>
                          <TableCell className="text-sm text-slate-600">
                            {formatDate(doc.issueDate)}
                          </TableCell>
                          <TableCell>
                            {doc.customer?.name || (
                              <span className="text-slate-400">Walk-in</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{TYPE_LABELS[doc.type]}</Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant="secondary" className="capitalize">
                              {doc.status.toLowerCase().replace(/_/g, " ")}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right font-medium">
                            {formatCurrency(doc.total)}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center justify-center gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => router.push(`/dashboard/pos/sales/${doc.id}`)}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() =>
                                  router.push(`/dashboard/pos/sales/${doc.id}?print=true`)
                                }
                              >
                                <Printer className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>
          </div>
        </>
      )}

      {/* ── Add Customer Dialog ── */}
      <AddCustomerDialog
        open={showAddCustomer}
        onOpenChange={setShowAddCustomer}
        token={token}
        onCustomerCreated={onCustomerCreated}
      />

      {/* ── New Sales Invoice Dialog ── */}
      <Dialog
        open={invoiceOpen}
        onOpenChange={(open) => {
          if (!open) handleInvoiceClose();
          else setInvoiceOpen(true);
        }}
      >
        <DialogContent className="max-h-[92vh] max-w-5xl overflow-y-auto sm:max-w-5xl">
          <DialogHeader>
            <DialogTitle>New Sales Invoice</DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {/* Customer */}
            <div>
              <Label className="mb-2 block text-sm font-medium">Customer</Label>
              <POSCustomerSelect
                token={token}
                selectedCustomer={invoiceCustomer}
                onCustomerSelect={setInvoiceCustomer}
              />
            </div>

            {/* Line Items */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-medium">Line Items</Label>
                <Button variant="outline" size="sm" onClick={addLineItem}>
                  <Plus className="mr-1 h-4 w-4" />
                  Add Row
                </Button>
              </div>

              <div className="space-y-4">
                {lineItems.map((item) => (
                  <div
                    key={item.key}
                    className="rounded-lg border bg-slate-50 p-4 space-y-3"
                  >
                    <div className="grid grid-cols-1 gap-3 md:grid-cols-12 md:items-end">
                      <div className="md:col-span-4">
                        <Label className="text-xs text-slate-600 mb-1 block">Product</Label>
                        <AutocompleteProductSearch
                          branchId={branchId}
                          token={token}
                          autoFocus={false}
                          onSelect={(product) => handleProductSelect(item.key, product)}
                        />
                      </div>
                      <div className="md:col-span-3">
                        <Label className="text-xs text-slate-600 mb-1 block">Description</Label>
                        <Input
                          value={item.description}
                          onChange={(e) =>
                            updateLineItem(item.key, { description: e.target.value })
                          }
                          placeholder="Description"
                          className="h-9"
                        />
                      </div>
                      <div className="md:col-span-1">
                        <Label className="text-xs text-slate-600 mb-1 block">Qty</Label>
                        <Input
                          type="number"
                          min={1}
                          value={item.quantity}
                          onChange={(e) =>
                            updateLineItem(item.key, {
                              quantity: Math.max(1, Number(e.target.value) || 1),
                            })
                          }
                          className="h-9"
                        />
                      </div>
                      <div className="md:col-span-2">
                        <Label className="text-xs text-slate-600 mb-1 block">Unit Price</Label>
                        <Input
                          type="number"
                          min={0}
                          step="0.01"
                          value={item.unitPrice}
                          onChange={(e) =>
                            updateLineItem(item.key, {
                              unitPrice: Math.max(0, Number(e.target.value) || 0),
                            })
                          }
                          className="h-9"
                        />
                      </div>
                      <div className="md:col-span-1">
                        <Label className="text-xs text-slate-600 mb-1 block">Tax %</Label>
                        <Input
                          type="number"
                          min={0}
                          step="0.01"
                          value={Math.round(item.taxRate * 100)}
                          onChange={(e) =>
                            updateLineItem(item.key, {
                              taxRate: Math.max(0, Number(e.target.value) || 0) / 100,
                            })
                          }
                          className="h-9"
                        />
                      </div>
                      <div className="md:col-span-1">
                        <Label className="text-xs text-slate-600 mb-1 block">Disc.</Label>
                        <Input
                          type="number"
                          min={0}
                          step="0.01"
                          value={item.discount}
                          onChange={(e) =>
                            updateLineItem(item.key, {
                              discount: Math.max(0, Number(e.target.value) || 0),
                            })
                          }
                          className="h-9"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">
                        Amount: {formatCurrency(calculateLineAmount(item))}
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        onClick={() => removeLineItem(item.key)}
                        disabled={lineItems.length <= 1}
                      >
                        <Trash2 className="mr-1 h-4 w-4" />
                        Remove
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Totals */}
            <div className="rounded-lg border bg-slate-50 p-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span>{formatCurrency(invoiceTotals.subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tax (16% VAT)</span>
                <span>{formatCurrency(invoiceTotals.tax)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Discount</span>
                <span>- {formatCurrency(invoiceTotals.discount)}</span>
              </div>
              <div className="border-t pt-2 flex justify-between text-base font-semibold">
                <span>Grand Total</span>
                <span>{formatCurrency(invoiceTotals.grandTotal)}</span>
              </div>
            </div>

            {/* Payment Method */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Payment Method</Label>
              <Select
                value={paymentMethod}
                onValueChange={(v) => setPaymentMethod(v as PaymentMethod)}
              >
                <SelectTrigger className="h-9 w-full md:w-64">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PAYMENT_METHODS.map((m) => (
                    <SelectItem key={m.value} value={m.value}>
                      {m.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Notes */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Notes</Label>
              <Textarea
                value={invoiceNotes}
                onChange={(e) => setInvoiceNotes(e.target.value)}
                placeholder="Optional notes..."
                rows={3}
              />
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={handleInvoiceClose} disabled={invoiceSaving}>
              Cancel
            </Button>
            <Button
              variant="outline"
              onClick={() => handleSaveDocument("DRAFT")}
              disabled={invoiceSaving}
            >
              {invoiceSaving ? "Saving..." : "Save as Draft"}
            </Button>
            <Button onClick={() => handleSaveDocument("INVOICE")} disabled={invoiceSaving}>
              {invoiceSaving ? "Creating..." : "Create Invoice"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
